# WA Notifier
WhatsApp message aane par aawaz mein bolta hai ke kis ka message aaya hai.
APK banane ke liye: GitHub pe upload karein -> Actions tab -> "Build APK" -> artifact "WaNotifier-apk" download karein.
